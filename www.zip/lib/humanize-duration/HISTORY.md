2.8.0 / 2015-05-10
==================

* new: `getSupportedLanguages`

2.7.0 / 2015-05-08
==================

* new: changelog
* new: Arabic support
* new: Italian support

* remove: (spoken) languages from package.json keywords
