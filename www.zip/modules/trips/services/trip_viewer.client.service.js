// by bwin on 8/10/15.

'use strict';

angular.module('trips').factory('TripViewer', [
    function() {
        var current_trip;
        var trips_collection;

        return {

        }
    }
]);